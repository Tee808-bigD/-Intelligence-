import { useState, useMemo } from "react";
import { CHAPTERS } from "./data/chapters";
import type { Chapter } from "./data/chapters";
import ChapterCard from "./components/ChapterCard";
import StudyRoom from "./components/StudyRoom";

type View = "dashboard" | "study";

export default function RE5Academy() {
  const [view, setView] = useState<View>("dashboard");
  const [activeChapter, setActiveChapter] = useState<Chapter | null>(null);
  const [chapterProgress, setChapterProgress] = useState<Record<number, number>>({});
  const [showIntro, setShowIntro] = useState(true);

  const totalProgress = useMemo(() => {
    if (CHAPTERS.length === 0) return 0;
    const sum = Object.values(chapterProgress).reduce((s, v) => s + v, 0);
    return Math.round(sum / CHAPTERS.length);
  }, [chapterProgress]);

  const handleProgress = (chapterId: number, pct: number) => {
    setChapterProgress((p) => ({
      ...p,
      [chapterId]: Math.max(p[chapterId] || 0, pct),
    }));
  };

  const openChapter = (chapter: Chapter) => {
    setActiveChapter(chapter);
    setView("study");
  };

  // Intro screen
  if (showIntro) {
    return (
      <div
        className="min-h-screen flex items-center justify-center relative overflow-hidden"
        style={{ background: "#020817" }}
      >
        {/* Animated background blobs */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {CHAPTERS.slice(0, 6).map((ch, i) => (
            <div
              key={i}
              className="absolute rounded-full"
              style={{
                width: `${300 + i * 100}px`,
                height: `${300 + i * 100}px`,
                background: `${ch.color}22`,
                top: `${(i * 17) % 80}%`,
                left: `${(i * 23) % 80}%`,
                animation: `glowAnim ${3 + i}s infinite alternate`,
                transform: "translate(-50%,-50%)",
                filter: "blur(60px)",
              }}
            />
          ))}
        </div>

        <div className="relative text-center max-w-xl px-8 z-10">
          <div className="text-8xl mb-6 fade-up">⚖️</div>
          <div className="fade-up delay-1">
            <div className="text-xs font-black uppercase tracking-[0.3em] text-blue-400 mb-3">
              South African Regulatory Examination
            </div>
            <h1 className="text-5xl font-black text-white leading-tight mb-4">
              RE5{" "}
              <span
                className="text-transparent bg-clip-text"
                style={{
                  backgroundImage:
                    "linear-gradient(90deg, #60a5fa, #818cf8, #a78bfa)",
                }}
              >
                Academy
              </span>
            </h1>
            <p className="text-white/50 text-base mb-2">
              The professional learning platform for Financial Services
              Representatives
            </p>
            <p className="text-white/30 text-sm mb-10">
              Complete coverage of the official RE5 Self-Study Guide (Sept
              2018)
            </p>
          </div>
          <div className="fade-up delay-2 grid grid-cols-3 gap-4 mb-10">
            {[
              ["8", "Chapters"],
              ["50+", "Topics"],
              ["60+", "Questions"],
            ].map(([n, l]) => (
              <div
                key={l}
                className="rounded-xl p-4"
                style={{ background: "rgba(255,255,255,0.05)" }}
              >
                <div className="text-2xl font-black text-white">{n}</div>
                <div className="text-white/40 text-xs">{l}</div>
              </div>
            ))}
          </div>
          <button
            onClick={() => setShowIntro(false)}
            className="fade-up delay-3 px-10 py-4 rounded-2xl font-black text-white text-lg transition-all hover:scale-105"
            style={{
              background: "linear-gradient(135deg, #1B4FD8, #7C3AED)",
            }}
          >
            Begin Learning →
          </button>
        </div>
      </div>
    );
  }

  if (view === "study" && activeChapter) {
    return (
      <StudyRoom
        chapter={activeChapter}
        onBack={() => setView("dashboard")}
        onProgressUpdate={handleProgress}
      />
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#020817" }}>
      {/* Navigation */}
      <nav
        className="sticky top-0 z-40 border-b border-white/5"
        style={{
          background: "rgba(2,8,23,0.98)",
          backdropFilter: "blur(20px)",
        }}
      >
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl">⚖️</div>
            <div>
              <div className="text-white font-black text-lg leading-none">
                RE5 Academy
              </div>
              <div className="text-white/30 text-xs">
                Professional Study Platform
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-white/40 mb-1">
                Overall Progress
              </div>
              <div className="flex items-center gap-2">
                <div
                  className="w-32 h-1.5 rounded-full overflow-hidden"
                  style={{ background: "rgba(255,255,255,0.1)" }}
                >
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${totalProgress}%`,
                      background:
                        "linear-gradient(90deg,#1B4FD8,#7C3AED)",
                    }}
                  />
                </div>
                <span className="text-white text-sm font-bold">
                  {totalProgress}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-10">
        {/* Hero Banner */}
        <div
          className="rounded-3xl p-8 mb-10 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, #0f172a, #1e1b4b)",
          }}
        >
          <div className="absolute inset-0 opacity-10">
            {CHAPTERS.map((ch, i) => (
              <div
                key={i}
                className="absolute rounded-full"
                style={{
                  width: `${200 + (i % 4) * 50}px`,
                  height: `${200 + (i % 4) * 50}px`,
                  background: ch.color,
                  top: `${(i * 13) % 90}%`,
                  left: `${(i * 17) % 90}%`,
                  transform: "translate(-50%,-50%)",
                  filter: "blur(60px)",
                }}
              />
            ))}
          </div>
          <div className="relative z-10">
            <div className="text-xs font-black uppercase tracking-[0.3em] text-blue-400 mb-3">
              RE5 — REPRESENTATIVES EXAMINATION
            </div>
            <h1 className="text-4xl font-black text-white mb-3">
              Your Path to{" "}
              <span
                className="text-transparent bg-clip-text"
                style={{
                  backgroundImage:
                    "linear-gradient(90deg,#60a5fa,#a78bfa)",
                }}
              >
                RE5 Success
              </span>
            </h1>
            <p className="text-white/50 max-w-xl mb-8">
              Complete, comprehensive study platform built from the official
              September 2018 RE5 Self-Study Guide. Every topic, every
              regulation, every exam tip — all in one place.
            </p>
            <div className="flex flex-wrap gap-4">
              {[
                { icon: "📋", label: "8 Full Chapters", sub: "Complete syllabus" },
                { icon: "🎬", label: "AI Video Lectures", sub: "Per topic" },
                { icon: "🧠", label: "60+ Practice Questions", sub: "RE5 style" },
                { icon: "💡", label: "Key Exam Facts", sub: "Highlighted" },
              ].map(({ icon, label, sub }) => (
                <div
                  key={label}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl"
                  style={{ background: "rgba(255,255,255,0.05)" }}
                >
                  <span className="text-xl">{icon}</span>
                  <div>
                    <div className="text-white text-sm font-bold">
                      {label}
                    </div>
                    <div className="text-white/40 text-xs">{sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mb-10">
          {[
            {
              label: "Chapters Completed",
              value: Object.values(chapterProgress).filter((v) => v >= 100).length,
              total: CHAPTERS.length,
              color: "#1B4FD8",
            },
            {
              label: "Topics Available",
              value: CHAPTERS.reduce((s, c) => s + c.topics.length, 0),
              total: null,
              color: "#7C3AED",
            },
            {
              label: "Practice Questions",
              value: CHAPTERS.reduce((s, c) => s + c.questions.length, 0),
              total: null,
              color: "#059669",
            },
            {
              label: "Overall Mastery",
              value: `${totalProgress}%`,
              total: null,
              color: "#D97706",
            },
          ].map(({ label, value, total, color }) => (
            <div
              key={label}
              className="rounded-2xl p-5"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <div className="text-3xl font-black mb-1" style={{ color }}>
                {value}
                {total !== null ? `/${total}` : ""}
              </div>
              <div className="text-white/40 text-xs uppercase tracking-wide">
                {label}
              </div>
            </div>
          ))}
        </div>

        {/* Chapters Grid */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-black text-2xl">Study Chapters</h2>
            <div className="text-white/40 text-sm">
              Select a chapter to begin studying
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {CHAPTERS.map((chapter) => (
              <ChapterCard
                key={chapter.id}
                chapter={chapter}
                onClick={() => openChapter(chapter)}
                progress={chapterProgress[chapter.id] || 0}
              />
            ))}
          </div>
        </div>

        {/* Important Timeframes Reference */}
        <div
          className="rounded-2xl p-6 mb-8"
          style={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <h3 className="text-white font-black text-lg mb-4">
            ⏰ Critical Timeframes — Quick Reference
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              {
                time: "5 Years",
                desc: "Minimum record keeping period (FAIS & FICA)",
                color: "#1B4FD8",
              },
              {
                time: "15 Days",
                desc: "Notify Registrar of any profile change",
                color: "#7C3AED",
              },
              {
                time: "21 Days",
                desc: "Representations to Registrar re: undesirable practices",
                color: "#DC2626",
              },
              {
                time: "60 Days",
                desc: "Rectify undesirable practice after direction",
                color: "#D97706",
              },
              {
                time: "2 Days",
                desc: "Report cash transactions above R25,000 to FIC",
                color: "#059669",
              },
              {
                time: "5 Days",
                desc: "Report suspicious transactions to FIC",
                color: "#7C2D12",
              },
              {
                time: "6 Years",
                desc: "Maximum period under supervision (representatives)",
                color: "#065F46",
              },
              {
                time: "1 Month",
                desc: "Minimum response period before license suspension",
                color: "#1E40AF",
              },
            ].map(({ time, desc, color }) => (
              <div
                key={time}
                className="rounded-xl p-3"
                style={{
                  background: `${color}15`,
                  border: `1px solid ${color}33`,
                }}
              >
                <div className="text-lg font-black mb-1" style={{ color }}>
                  {time}
                </div>
                <div className="text-white/60 text-xs leading-relaxed">
                  {desc}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-white/20 text-xs">
          RE5 Academy · Built from the Official SA RE5 Self-Study Guide
          (September 2018) · For Representatives
        </div>
      </div>
    </div>
  );
}

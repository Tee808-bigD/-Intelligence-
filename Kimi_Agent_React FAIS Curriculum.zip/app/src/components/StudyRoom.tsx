import { useState } from "react";
import type { Chapter } from "../data/chapters";
import VideoPlayer from "./VideoPlayer";
import Quiz from "./Quiz";

interface StudyRoomProps {
  chapter: Chapter;
  onBack: () => void;
  onProgressUpdate: (chapterId: number, pct: number) => void;
}

export default function StudyRoom({
  chapter,
  onBack,
  onProgressUpdate,
}: StudyRoomProps) {
  const [activeVideo, setActiveVideo] = useState<Chapter["topics"][number] | null>(null);
  const [activeQuiz, setActiveQuiz] = useState(false);
  const [completedTopics, setCompletedTopics] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<"topics" | "notes">("topics");

  const handleTopicComplete = (topicId: string) => {
    setCompletedTopics((p) => {
      const n = new Set(p);
      n.add(topicId);
      return n;
    });
    const nextSize = completedTopics.has(topicId)
      ? completedTopics.size
      : completedTopics.size + 1;
    const pct = Math.round((nextSize / chapter.topics.length) * 100);
    onProgressUpdate(chapter.id, pct);
  };

  const handleQuizComplete = (score: number) => {
    if (score >= 70) onProgressUpdate(chapter.id, 100);
  };

  return (
    <div className="min-h-screen" style={{ background: "#020817" }}>
      {activeVideo && (
        <VideoPlayer
          topic={activeVideo}
          chapter={chapter}
          onClose={() => {
            setActiveVideo(null);
            handleTopicComplete(activeVideo.id);
          }}
        />
      )}
      {activeQuiz && (
        <Quiz
          chapter={chapter}
          onClose={() => setActiveQuiz(false)}
          onComplete={handleQuizComplete}
        />
      )}

      {/* Study Room Header */}
      <div
        className="sticky top-0 z-30 border-b border-white/5"
        style={{
          background: "rgba(2,8,23,0.95)",
          backdropFilter: "blur(20px)",
        }}
      >
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-4">
          <button
            onClick={onBack}
            className="text-white/60 hover:text-white transition-colors flex items-center gap-2 text-sm"
          >
            ← Back
          </button>
          <div className="w-px h-6 bg-white/10" />
          <div className="text-2xl">{chapter.icon}</div>
          <div>
            <div className="text-xs text-white/40 uppercase tracking-widest">
              Chapter {chapter.id}
            </div>
            <div className="text-white font-bold">{chapter.shortTitle}</div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* Chapter Hero */}
        <div
          className="rounded-2xl p-8 mb-8 relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${chapter.color}33, ${chapter.color}11)`,
            border: `1px solid ${chapter.color}33`,
          }}
        >
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-4">
              <span className="text-5xl">{chapter.icon}</span>
              <div>
                <div
                  className="text-xs font-bold uppercase tracking-widest mb-1"
                  style={{ color: chapter.color }}
                >
                  Chapter {chapter.id}
                </div>
                <h1 className="text-2xl font-black text-white">
                  {chapter.title}
                </h1>
              </div>
            </div>
            <p className="text-white/60 mb-6 max-w-2xl">
              {chapter.description}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setActiveTab("topics")}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                  activeTab === "topics"
                    ? "text-white"
                    : "text-white/50 hover:text-white"
                }`}
                style={
                  activeTab === "topics"
                    ? { background: chapter.color }
                    : { background: "rgba(255,255,255,0.05)" }
                }
              >
                📚 Study Topics
              </button>
              <button
                onClick={() => setActiveTab("notes")}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                  activeTab === "notes"
                    ? "text-white"
                    : "text-white/50 hover:text-white"
                }`}
                style={
                  activeTab === "notes"
                    ? { background: chapter.color }
                    : { background: "rgba(255,255,255,0.05)" }
                }
              >
                📝 Key Summaries
              </button>
            </div>
          </div>
        </div>

        {activeTab === "topics" && (
          <>
            {/* Topics Grid */}
            <div className="grid gap-4 mb-8">
              {chapter.topics.map((topic, i) => {
                const done = completedTopics.has(topic.id);
                return (
                  <div
                    key={topic.id}
                    className="rounded-2xl p-6 transition-all"
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      border: `1px solid ${
                        done
                          ? chapter.color + "44"
                          : "rgba(255,255,255,0.06)"
                      }`,
                    }}
                  >
                    <div className="flex items-center justify-between flex-wrap gap-4">
                      <div className="flex items-center gap-4">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm"
                          style={{
                            background: done
                              ? chapter.color
                              : "rgba(255,255,255,0.08)",
                            color: "white",
                          }}
                        >
                          {done ? "✓" : i + 1}
                        </div>
                        <div>
                          <div className="text-white font-bold mb-1">
                            {topic.title}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-white/40">
                            <span>🎬 {topic.slides.length} slides</span>
                            <span>⏱ {topic.duration}</span>
                            {done && (
                              <span
                                className="font-bold"
                                style={{ color: chapter.color }}
                              >
                                ✓ Completed
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => setActiveVideo(topic)}
                        className="px-5 py-2.5 rounded-xl font-bold text-sm text-white transition-all hover:scale-105"
                        style={{
                          background: done
                            ? "rgba(255,255,255,0.1)"
                            : chapter.color,
                        }}
                      >
                        {done ? "↺ Review" : "▶ Start Lecture"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Practice Quiz CTA */}
            <div
              className="rounded-2xl p-6 text-center"
              style={{
                background:
                  "linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02))",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <div className="text-3xl mb-3">🧠</div>
              <div className="text-white font-black text-xl mb-2">
                Ready to Test Your Knowledge?
              </div>
              <div className="text-white/50 text-sm mb-6">
                {chapter.questions.length} carefully crafted RE5-style questions
                for this chapter
              </div>
              <button
                onClick={() => setActiveQuiz(true)}
                className="px-8 py-3 rounded-xl font-bold text-white text-sm transition-all hover:scale-105"
                style={{ background: chapter.color }}
              >
                Start Practice Quiz →
              </button>
            </div>
          </>
        )}

        {activeTab === "notes" && (
          <div className="space-y-4">
            {chapter.topics.map((topic) => (
              <div
                key={topic.id}
                className="rounded-2xl overflow-hidden"
                style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div className="px-6 py-4 border-b border-white/5">
                  <div className="text-white font-bold">{topic.title}</div>
                </div>
                <div className="p-6 space-y-4">
                  {topic.slides.map((slide, i) => (
                    <div
                      key={i}
                      className="rounded-xl p-4"
                      style={{ background: "rgba(255,255,255,0.03)" }}
                    >
                      <div
                        className="text-xs font-bold uppercase tracking-widest mb-2"
                        style={{ color: slide.color }}
                      >
                        {slide.heading}
                      </div>
                      <div className="text-white/70 text-sm leading-relaxed whitespace-pre-line mb-3">
                        {slide.body}
                      </div>
                      <div
                        className="flex items-start gap-2 p-3 rounded-lg"
                        style={{ background: `${slide.color}15` }}
                      >
                        <span className="text-sm">💡</span>
                        <div className="text-xs text-white/60">
                          {slide.keyFact}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

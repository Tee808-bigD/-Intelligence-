import { useState } from "react";
import type { Chapter } from "../data/chapters";

interface QuizProps {
  chapter: Chapter;
  onClose: () => void;
  onComplete: (score: number) => void;
}

export default function Quiz({ chapter, onClose, onComplete }: QuizProps) {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const q = chapter.questions[current];

  const handleSelect = (idx: number) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    const correct = idx === q.correct;
    if (correct) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (current < chapter.questions.length - 1) {
      setCurrent((c) => c + 1);
      setSelected(null);
      setAnswered(false);
    } else {
      setFinished(true);
    }
  };

  const handleRetry = () => {
    setCurrent(0);
    setSelected(null);
    setAnswered(false);
    setScore(0);
    setFinished(false);
  };

  const pct = Math.round((score / chapter.questions.length) * 100);

  if (finished) {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ background: "rgba(0,0,0,0.9)" }}
      >
        <div
          className="w-full max-w-md mx-4 rounded-2xl overflow-hidden shadow-2xl"
          style={{ background: "#0f172a" }}
        >
          <div className="p-8 text-center">
            <div className="text-7xl mb-4">
              {pct >= 80 ? "🏆" : pct >= 60 ? "👍" : "📚"}
            </div>
            <div className="text-3xl font-black text-white mb-2">
              {pct >= 80 ? "Excellent!" : pct >= 60 ? "Good Work!" : "Keep Studying!"}
            </div>
            <div className="text-white/60 mb-6">
              You scored {score} of {chapter.questions.length} ({pct}%)
            </div>
            <div
              className="rounded-xl p-4 mb-6"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <div className="text-xs uppercase tracking-widest text-white/40 mb-2">
                Performance
              </div>
              <div
                className="w-full rounded-full overflow-hidden mb-2"
                style={{ height: "8px", background: "rgba(255,255,255,0.1)" }}
              >
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${pct}%`,
                    background:
                      pct >= 80 ? "#10b981" : pct >= 60 ? "#f59e0b" : "#ef4444",
                  }}
                />
              </div>
              <div className="text-white font-bold text-2xl">{pct}%</div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleRetry}
                className="flex-1 py-3 rounded-xl font-bold text-white transition-all"
                style={{ background: "rgba(255,255,255,0.1)" }}
              >
                Retry
              </button>
              <button
                onClick={() => {
                  onComplete(pct);
                  onClose();
                }}
                className="flex-1 py-3 rounded-xl font-bold text-white transition-all"
                style={{ background: chapter.color }}
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: "rgba(0,0,0,0.9)" }}
    >
      <div
        className="w-full max-w-2xl mx-4 rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: "#0f172a" }}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <div
              className="text-xs font-semibold uppercase tracking-widest mb-1"
              style={{ color: chapter.color }}
            >
              Practice Quiz
            </div>
            <div className="text-white font-bold">{chapter.shortTitle}</div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-white/60 text-sm">
              Question {current + 1}/{chapter.questions.length}
            </span>
            <button
              onClick={onClose}
              className="text-white/60 hover:text-white"
            >
              ✕
            </button>
          </div>
        </div>
        <div className="p-6">
          <div
            className="w-full rounded-full overflow-hidden mb-6"
            style={{ height: "4px", background: "rgba(255,255,255,0.1)" }}
          >
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${(current / chapter.questions.length) * 100}%`,
                background: chapter.color,
              }}
            />
          </div>
          <div className="text-white font-bold text-lg mb-6 leading-relaxed">
            {q.q}
          </div>
          <div className="space-y-3 mb-6">
            {q.opts.map((opt, i) => {
              let bg = "rgba(255,255,255,0.05)";
              let border = "transparent";
              let text = "text-white/80";
              if (answered) {
                if (i === q.correct) {
                  bg = "rgba(16,185,129,0.15)";
                  border = "#10b981";
                  text = "text-emerald-400";
                } else if (
                  i === selected &&
                  i !== q.correct
                ) {
                  bg = "rgba(239,68,68,0.15)";
                  border = "#ef4444";
                  text = "text-red-400";
                }
              } else if (selected === i) {
                bg = "rgba(255,255,255,0.1)";
                border = chapter.color;
              }
              return (
                <button
                  key={i}
                  onClick={() => handleSelect(i)}
                  className={`w-full text-left p-4 rounded-xl transition-all border ${text}`}
                  style={{
                    background: bg,
                    borderColor: border,
                    borderWidth: "1px",
                  }}
                >
                  <div className="flex items-start gap-3">
                    <span className="font-bold text-sm mt-0.5 opacity-60">
                      {String.fromCharCode(65 + i)}.
                    </span>
                    <span className="text-sm leading-relaxed">{opt}</span>
                  </div>
                </button>
              );
            })}
          </div>
          {answered && (
            <div
              className="rounded-xl p-4 mb-4"
              style={{ background: "rgba(255,255,255,0.05)" }}
            >
              <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-2">
                Explanation
              </div>
              <div className="text-white/70 text-sm leading-relaxed">
                {q.exp}
              </div>
            </div>
          )}
          {answered && (
            <button
              onClick={handleNext}
              className="w-full py-3 rounded-xl font-bold text-white transition-all"
              style={{ background: chapter.color }}
            >
              {current < chapter.questions.length - 1
                ? "Next Question →"
                : "View Results"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

import type { Chapter } from "../data/chapters";

interface ChapterCardProps {
  chapter: Chapter;
  onClick: () => void;
  progress: number;
}

export default function ChapterCard({
  chapter,
  onClick,
  progress,
}: ChapterCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl group"
      style={{
        background: "linear-gradient(135deg, #1e293b, #0f172a)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div
        className="h-2"
        style={{
          background: `linear-gradient(90deg, ${chapter.color}, ${chapter.color}88)`,
        }}
      />
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="text-3xl">{chapter.icon}</div>
          <div
            className="text-xs font-bold uppercase tracking-widest px-2 py-1 rounded-full"
            style={{
              background: `${chapter.color}22`,
              color: chapter.color,
            }}
          >
            Ch. {chapter.id}
          </div>
        </div>
        <div className="text-white font-bold text-base mb-2 leading-snug group-hover:text-blue-300 transition-colors">
          {chapter.title}
        </div>
        <div className="text-white/50 text-xs mb-4 line-clamp-2">
          {chapter.description}
        </div>
        <div className="flex items-center justify-between text-xs text-white/40 mb-3">
          <span>
            {chapter.topics.length} topics · {chapter.questions.length}{" "}
            questions
          </span>
          <span>{progress}%</span>
        </div>
        <div
          className="w-full rounded-full overflow-hidden"
          style={{ height: "3px", background: "rgba(255,255,255,0.1)" }}
        >
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${progress}%`, background: chapter.color }}
          />
        </div>
      </div>
    </button>
  );
}

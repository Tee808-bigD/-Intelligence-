import { useState, useEffect, useRef, useCallback } from "react";
import type { Topic, Chapter } from "../data/chapters";

interface VideoPlayerProps {
  topic: Topic;
  chapter: Chapter;
  onClose: () => void;
}

export default function VideoPlayer({ topic, chapter, onClose }: VideoPlayerProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showKeyFact, setShowKeyFact] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const totalDuration = topic.slides.length * 15;
  const slide = topic.slides[currentSlide];

  useEffect(() => {
    setCurrentSlide(0);
    setProgress(0);
    setElapsed(0);
    setPlaying(false);
    setShowKeyFact(false);
  }, [topic]);

  useEffect(() => {
    if (playing) {
      intervalRef.current = setInterval(() => {
        setElapsed((e) => {
          const next = e + 0.1;
          const pct = (next / totalDuration) * 100;
          setProgress(Math.min(pct, 100));
          const slideIdx = Math.floor(
            (next / totalDuration) * topic.slides.length
          );
          const newSlide = Math.min(slideIdx, topic.slides.length - 1);
          setCurrentSlide(newSlide);
          if (Math.floor(next % 15) === 7) setShowKeyFact(true);
          else if (Math.floor(next % 15) === 0) setShowKeyFact(false);
          if (next >= totalDuration) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            setPlaying(false);
            return totalDuration;
          }
          return next;
        });
      }, 100);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [playing, topic, totalDuration]);

  const formatTime = (s: number) =>
    `${Math.floor(s / 60)
      .toString()
      .padStart(2, "0")}:${Math.floor(s % 60)
      .toString()
      .padStart(2, "0")}`;

  const goToSlide = useCallback(
    (n: number) => {
      const clamped = Math.max(0, Math.min(topic.slides.length - 1, n));
      setCurrentSlide(clamped);
      setElapsed((clamped / topic.slides.length) * totalDuration);
    },
    [topic.slides.length, totalDuration]
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: "rgba(0,0,0,0.92)" }}
    >
      <div
        className="relative w-full max-w-4xl mx-4 rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: "#0f172a" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <div className="text-xs font-semibold text-blue-400 uppercase tracking-widest mb-1">
              Chapter {chapter.id} — {chapter.shortTitle}
            </div>
            <div className="text-white font-bold text-lg">{topic.title}</div>
          </div>
          <button
            onClick={onClose}
            className="text-white/60 hover:text-white text-2xl transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Slide Area */}
        <div
          className="relative overflow-hidden"
          style={{
            height: "380px",
            background: `linear-gradient(135deg, ${slide.color}22, ${slide.color}08)`,
          }}
        >
          {/* Animated background */}
          <div className="absolute inset-0 opacity-5">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full"
                style={{
                  width: `${Math.random() * 200 + 50}px`,
                  height: `${Math.random() * 200 + 50}px`,
                  background: slide.color,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  opacity: 0.3,
                  transform: "translate(-50%,-50%)",
                  animation: `pulseAnim ${2 + Math.random() * 3}s infinite alternate`,
                }}
              />
            ))}
          </div>

          <div className="relative z-10 flex h-full flex-col items-center justify-center px-12 text-center">
            {/* Slide number */}
            <div className="absolute top-4 right-6 flex gap-2">
              {topic.slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => goToSlide(i)}
                  className="w-2 h-2 rounded-full transition-all"
                  style={{
                    background:
                      i === currentSlide
                        ? slide.color
                        : "rgba(255,255,255,0.3)",
                    transform:
                      i === currentSlide ? "scale(1.5)" : "scale(1)",
                  }}
                />
              ))}
            </div>

            <div
              className="text-xs font-bold uppercase tracking-widest mb-4"
              style={{ color: slide.color }}
            >
              Slide {currentSlide + 1} of {topic.slides.length}
            </div>
            <h2 className="text-3xl font-black text-white mb-6 leading-tight">
              {slide.heading}
            </h2>
            <div className="text-white/80 text-sm leading-relaxed max-w-2xl whitespace-pre-line">
              {slide.body}
            </div>
          </div>

          {/* Key Fact Banner */}
          {showKeyFact && (
            <div
              className="absolute bottom-0 left-0 right-0 px-6 py-4 flex items-start gap-3"
              style={{
                background: `linear-gradient(0deg, ${slide.color}ee, transparent)`,
              }}
            >
              <span className="text-2xl mt-0.5">💡</span>
              <div>
                <div className="text-xs font-black uppercase tracking-widest text-white/60 mb-1">
                  KEY EXAM FACT
                </div>
                <div className="text-white font-semibold text-sm">
                  {slide.keyFact}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="px-6 py-4">
          {/* Progress Bar */}
          <div
            className="mb-3 rounded-full overflow-hidden"
            style={{ height: "4px", background: "rgba(255,255,255,0.1)" }}
          >
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${progress}%`,
                background: `linear-gradient(90deg, ${slide.color}, #60a5fa)`,
              }}
            />
          </div>
          <div className="flex items-center justify-between text-white/50 text-xs mb-4">
            <span>{formatTime(elapsed)}</span>
            <span>{formatTime(totalDuration)}</span>
          </div>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => goToSlide(currentSlide - 1)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-all text-lg"
            >
              ⏮
            </button>
            <button
              onClick={() => setPlaying(!playing)}
              className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl transition-all"
              style={{ background: slide.color }}
            >
              {playing ? "⏸" : "▶"}
            </button>
            <button
              onClick={() => goToSlide(currentSlide + 1)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-all text-lg"
            >
              ⏭
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
